import random
import json
import os
import math
import wave

try:
    import winsound
except ImportError:
    winsound = None

# ==========================================
# GIZEMLI MACERA - SISTEMLER TAMAMLANDI
# Testler en sona birakilmak uzere tum ana ilerleme sistemleri tek dosyada toplandi.
# ==========================================

SAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kayit.json")
MUSIC_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gizemli_macera_muzik.wav")

# Bolum ilerleme / ekipman kilitleri
BOLUM_SEVIYELERI = {"Magarayi Kesfet": 2, "Dag Muhafizini Yen": 2, "Col Hazinesi": 3, "Gizemli Portala Gir": 4}


oyuncu = {
    "isim": "",
    "can": 100,
    "max_can": 100,
    "mana": 50,
    "max_mana": 50,
    "altin": 2000,
    "seviye": 1,
    "xp": 0,
    "saldiri": 10,
    "savunma": 0,
    "konum": "Koy",
    "gorev": "Kristali Bul",
    "skill_puani": 0,
    "silah": "Baslangic Kilici",
    "silah_plus": 0,
    "kostum": "Gezgin Kostumu",
    "kostum_seviye": 0,
    "binek": "Yok",
    "binek_hiz": 0,
    "hiz_potu": 0,
}

envanter = {"Can Iksiri": 3}

yetenekler = {
    "Guclu Darbe": 0,
    "Kritik Vurus": 0,
    "Can Yenileme": 0,
    "Mana Ustaligi": 0,
}

oyun_bitti = False

basarimlar = {
    "Ilk Kan": False,
    "Karanligin Sonu": False,
    "Daglarin Efendisi": False,
    "Col Fatihi": False,
    "Portal Savascisi": False,
    "Gizemli Macera": False,
    "Zengin": False,
    "Usta Savasci": False,
}

# ==========================================
# ESYA / EKIPMAN TABLOLARI
# ==========================================

SILAH_SEVIYELERI = {
    "Baslangic Kilici": {"taban": 0, "maliyet": 80, "artis": 4, "max": 5},
    "Golge Kilici": {"taban": 5, "maliyet": 140, "artis": 6, "max": 8},
    "Kristal Kilici": {"taban": 12, "maliyet": 220, "artis": 8, "max": 10},
}

KOSTUMLER = {
    "Gezgin Kostumu": {"savunma": 0, "maliyet": 0},
    "Muhafiz Kostumu": {"savunma": 5, "maliyet": 250},
    "Golge Kostumu": {"savunma": 10, "maliyet": 500},
}

BINEKLER = {
    "At": {"hiz": 2, "maliyet": 300},
    "Golge Binegi": {"hiz": 4, "maliyet": 650},
}

# Bolum bazli dusmanlar. Gecisler gorev ile kontrol edilir.
DUSMANLAR = {
    "Orman": ("Goblin", 85, 16, 45, 40),
    "Magara": ("Tas Golem", 150, 18, 150, 100),
    "Dag": ("Dag Muhafizi", 280, 24, 250, 250),
    "Col": ("Col Canavari", 400, 29, 350, 350),
    "Portal": ("Karanlik Lordu", 700, 42, 1000, 1000),
}

GOREV_SIRASI = [
    "Kristali Bul",
    "Magarayi Kesfet",
    "Dag Muhafizini Yen",
    "Col Hazinesi",
    "Gizemli Portala Gir",
    "Oyun Tamamlandi",
]

# ==========================================
# YARDIMCI
# ==========================================

def muzik_hazirla_ve_baslat():
    """Harici muzik gerektirmeyen, telifsiz basit arka plan muzigi olusturur ve Windows'ta dongude calar."""
    if winsound is None:
        return
    try:
        if not os.path.exists(MUSIC_FILE):
            rate = 22050
            sure = 12
            melodi = [220, 262, 294, 330, 294, 262, 196, 220, 262, 330, 392, 330]
            frames = bytearray()
            for i in range(rate * sure):
                nota = melodi[(i // (rate // 2)) % len(melodi)]
                t = i / rate
                sample = int(9000 * math.sin(2 * math.pi * nota * t) * (0.55 + 0.2 * math.sin(2 * math.pi * 2 * t)))
                frames += int(sample).to_bytes(2, byteorder="little", signed=True)
            with wave.open(MUSIC_FILE, "wb") as wav:            
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(rate)
                wav.writeframes(frames)
        winsound.PlaySound(MUSIC_FILE, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
    except Exception:
        pass

def muzik_durdur():
    if winsound is not None:
        try:
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            pass


def bekle():
    input("\nDevam etmek icin Enter...")


def temizle():
    os.system("cls" if os.name == "nt" else "clear")


def esya_ekle(esya, miktar=1):
    envanter[esya] = envanter.get(esya, 0) + miktar


def esya_kullan(esya):
    if envanter.get(esya, 0) <= 0:
        return False
    envanter[esya] -= 1
    if envanter[esya] <= 0:
        del envanter[esya]
    return True


def silah_saldirisi():
    bilgi = SILAH_SEVIYELERI.get(oyuncu["silah"], SILAH_SEVIYELERI["Baslangic Kilici"])
    return oyuncu["saldiri"] + bilgi["taban"] + oyuncu["silah_plus"] * bilgi["artis"]


def toplam_savunma():
    kostum = KOSTUMLER.get(oyuncu["kostum"], KOSTUMLER["Gezgin Kostumu"])
    return oyuncu["savunma"] + kostum["savunma"] + oyuncu["kostum_seviye"] * 2


def xp_esigi():
    return oyuncu["seviye"] * 100

# ==========================================
# KAYIT
# ==========================================

def kayitla_sessiz():
    veri = {
        "oyuncu": oyuncu.copy(),
        "envanter": envanter.copy(),
        "yetenekler": yetenekler.copy(),
        "basarimlar": basarimlar.copy(),
        "surum": 6,
    }
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as dosya:
            json.dump(veri, dosya, ensure_ascii=False, indent=4)
    except OSError:
        pass


def kaydet():
    veri = {
        "oyuncu": oyuncu.copy(),
        "envanter": envanter.copy(),
        "yetenekler": yetenekler.copy(),
        "basarimlar": basarimlar.copy(),
        "surum": 6,
    }
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as dosya:
            json.dump(veri, dosya, ensure_ascii=False, indent=4)
        print("\nOyun kaydedildi!")
    except OSError:
        print("\nKayit yapilamadi!")
    bekle()


def kayit_yukle():
    global oyun_bitti
    if not os.path.exists(SAVE_FILE):
        print("\nKayit dosyasi bulunamadi!")
        bekle()
        return False
    try:
        with open(SAVE_FILE, "r", encoding="utf-8") as dosya:
            veri = json.load(dosya)

        # Yeni kayit formati
        if isinstance(veri.get("oyuncu"), dict):
            oyuncu.update(veri["oyuncu"])
            envanter.clear()
            envanter.update(veri.get("envanter", {}))
            yetenekler.update(veri.get("yetenekler", {}))
            basarimlar.update(veri.get("basarimlar", {}))
        else:
            # Eski kayitlarla uyum
            for anahtar in oyuncu:
                if anahtar in veri:
                    oyuncu[anahtar] = veri[anahtar]
            envanter.clear()
            for esya in veri.get("envanter", []):
                esya_ekle(esya)
            yetenekler.update(veri.get("yetenekler_seviye", {}))
            basarimlar.update(veri.get("basarimlar", {}))

        oyun_bitti = oyuncu.get("gorev") == "Oyun Tamamlandi"

        # Eksik yeni alanlari guvenli varsayilanlarla tamamla.
        oyuncu.setdefault("savunma", 0)
        oyuncu.setdefault("silah", "Baslangic Kilici")
        oyuncu.setdefault("silah_plus", 0)
        oyuncu.setdefault("kostum", "Gezgin Kostumu")
        oyuncu.setdefault("kostum_seviye", 0)
        oyuncu.setdefault("binek", "Yok")
        oyuncu.setdefault("binek_hiz", 0)
        oyuncu.setdefault("hiz_potu", 0)

        print("\nKayit basariyla yuklendi!")
        bekle()
        return True
    except (json.JSONDecodeError, OSError, TypeError, ValueError):
        print("\nKayit dosyasi okunamadi!")
        bekle()
        return False

# ==========================================
# XP / ALTIN / BASARIM
# ==========================================

def xp_kazan(miktar):
    oyuncu["xp"] += miktar
    print("\nKazandigin XP:", miktar)

    # Her seviye icin gereken XP once mevcut toplamdan dusurulur.
    # Boylece tek bir odul oyuncuyu art arda onlarca seviye atlatmaz.
    while oyuncu["xp"] >= xp_esigi():
        gereken = xp_esigi()
        oyuncu["xp"] -= gereken
        oyuncu["seviye"] += 1
        oyuncu["max_can"] += 20
        oyuncu["can"] = oyuncu["max_can"]
        oyuncu["max_mana"] += 10
        oyuncu["mana"] = oyuncu["max_mana"]
        oyuncu["saldiri"] += 5
        oyuncu["savunma"] += 1
        oyuncu["skill_puani"] += 1
        print("\nSEVIYE ATLADIN! Yeni Seviye:", oyuncu["seviye"])
        print("Can +20 | Mana +10 | Saldiri +5 | Savunma +1 | Skill +1")


def altin_kazan(miktar):
    oyuncu["altin"] += miktar
    print("Kazandigin altin:", miktar)


def basarim_kontrol():
    if oyuncu["xp"] > 0:
        basarimlar["Ilk Kan"] = True
    if oyuncu["altin"] >= 500:
        basarimlar["Zengin"] = True
    if oyuncu["seviye"] >= 10:
        basarimlar["Usta Savasci"] = True
    if oyuncu["gorev"] in GOREV_SIRASI[2:]:
        basarimlar["Karanligin Sonu"] = True
    if oyuncu["gorev"] in GOREV_SIRASI[3:]:
        basarimlar["Daglarin Efendisi"] = True
    if oyuncu["gorev"] in GOREV_SIRASI[4:]:
        basarimlar["Col Fatihi"] = True
    if oyuncu["gorev"] == "Oyun Tamamlandi":
        basarimlar["Portal Savascisi"] = True
        basarimlar["Gizemli Macera"] = True


def basarimlari_goster():
    temizle()
    print("================================")
    print("           BASARIMLAR")
    print("================================")
    basarim_kontrol()
    for ad, durum in basarimlar.items():
        print("[TAMAM]" if durum else "[KILITLI]", ad)
    bekle()

# ==========================================
# YETENEKLER
# ==========================================

def yetenekler_menu():
    isimler = {"1": "Guclu Darbe", "2": "Kritik Vurus", "3": "Can Yenileme", "4": "Mana Ustaligi"}
    while True:
        temizle()
        print("================================")
        print("           YETENEKLER")
        print("================================")
        print("Skill Puani:", oyuncu["skill_puani"])
        print("1 - Guclu Darbe  Seviye:", yetenekler["Guclu Darbe"])
        print("2 - Kritik Vurus Seviye:", yetenekler["Kritik Vurus"])
        print("3 - Can Yenileme Seviye:", yetenekler["Can Yenileme"])
        print("4 - Mana Ustaligi Seviye:", yetenekler["Mana Ustaligi"])
        print("5 - Geri Don")
        secim = input("\nSecimin: ")
        if secim == "5":
            return
        if secim not in isimler or oyuncu["skill_puani"] <= 0:
            print("Yeterli skill puanin yok veya gecersiz secim!")
            bekle()
            continue
        yetenekler[isimler[secim]] += 1
        oyuncu["skill_puani"] -= 1
        print(isimler[secim], "gelistirildi!")
        bekle()

# ==========================================
# GOREV / BOLUM TAKIP
# ==========================================

def bolum_bilgisi():
    durumlar = []
    for i, gorev in enumerate(GOREV_SIRASI[:-1], 1):
        if oyuncu["gorev"] == gorev:
            durum = "AKTIF"
        elif GOREV_SIRASI.index(oyuncu["gorev"]) > i - 1:
            durum = "TAMAM"
        else:
            durum = "KILITLI"
        durumlar.append((i, gorev, durum))
    temizle()
    print("================================")
    print("          BOLUM DURUMU")
    print("================================")
    for no, gorev, durum in durumlar:
        print(str(no) + ".", gorev, "[" + durum + "]")
    print("\nMevcut gorev:", oyuncu["gorev"])
    bekle()

# ==========================================
# ENVANTER / KARAKTER
# ==========================================

def envanter_goster():
    temizle()
    print("================================")
    print("           ENVANTER")
    print("================================")
    for esya, miktar in envanter.items():
        print("-", esya, "x" + str(miktar))
    print("\n1 - Can Iksiri Kullan")
    print("2 - Geri Don")
    secim = input("\nSecimin: ")
    if secim == "1":
        if esya_kullan("Can Iksiri"):
            iyilesme = 80 + yetenekler["Can Yenileme"] * 20
            oyuncu["can"] = min(oyuncu["max_can"], oyuncu["can"] + iyilesme)
            print("Can yenilendi!")
        else:
            print("Can iksirin yok!")
        bekle()


def karakter():
    temizle()
    print("================================")
    print("            KARAKTER")
    print("================================")
    print("Isim:", oyuncu["isim"])
    print("Can:", oyuncu["can"], "/", oyuncu["max_can"])
    print("Mana:", oyuncu["mana"], "/", oyuncu["max_mana"])
    print("Altin:", oyuncu["altin"])
    print("Seviye:", oyuncu["seviye"], "XP:", oyuncu["xp"])
    print("Saldiri:", silah_saldirisi())
    print("Savunma:", toplam_savunma())
    print("Silah:", oyuncu["silah"], "+" + str(oyuncu["silah_plus"]))
    print("Kostum:", oyuncu["kostum"], "+" + str(oyuncu["kostum_seviye"]))
    print("Binek:", oyuncu["binek"], "Hiz:", oyuncu["binek_hiz"])
    print("Gorev:", oyuncu["gorev"])
    bekle()

# ==========================================
# GELISTIRMELER: SILAH + / KOSTUM / BINEK
# ==========================================

def gelistirmeler():
    while True:
        temizle()
        print("================================")
        print("          GELISTIRMELER")
        print("================================")
        print("Altin:", oyuncu["altin"])
        print("1 - Silah +1")
        print("2 - Kostum +1")
        print("3 - Yeni silah al")
        print("4 - Kostum al")
        print("5 - Binek al")
        print("6 - Hiz Potu al (100 Altin)")
        print("7 - Geri Don")
        secim = input("\nSecimin: ")

        if secim == "7":
            return
        if secim == "1":
            bilgi = SILAH_SEVIYELERI[oyuncu["silah"]]
            seviye = oyuncu["silah_plus"]
            if seviye >= bilgi["max"]:
                print("Silah maksimum seviyede!")
            else:
                maliyet = bilgi["maliyet"] * (seviye + 1)
                if oyuncu["altin"] >= maliyet:
                    oyuncu["altin"] -= maliyet
                    oyuncu["silah_plus"] += 1
                    kayitla_sessiz()
                    print("Silah +", oyuncu["silah_plus"], "oldu!")
                else:
                    print("Yeterli altinin yok!")
            bekle()
        elif secim == "2":
            if oyuncu["kostum_seviye"] >= 5:
                print("Kostum maksimum seviyede!")
            else:
                maliyet = 100 * (oyuncu["kostum_seviye"] + 1)
                if oyuncu["altin"] >= maliyet:
                    oyuncu["altin"] -= maliyet
                    oyuncu["kostum_seviye"] += 1
                    kayitla_sessiz()
                    print("Kostum +", oyuncu["kostum_seviye"], "oldu!")
                else:
                    print("Yeterli altinin yok!")
            bekle()
        elif secim == "3":
            print("Mevcut silah:", oyuncu["silah"])
            for ad, bilgi in SILAH_SEVIYELERI.items():
                print(ad, "-", bilgi["maliyet"], "Altin")
            ad = input("Almak istedigin silah: ").strip()
            if ad in SILAH_SEVIYELERI and ad != oyuncu["silah"]:
                maliyet = SILAH_SEVIYELERI[ad]["maliyet"]
                if oyuncu["altin"] >= maliyet:
                    oyuncu["altin"] -= maliyet
                    oyuncu["silah"] = ad
                    oyuncu["silah_plus"] = 0
                    kayitla_sessiz()
                    print(ad, "alindi!")
                else:
                    print("Yeterli altinin yok!")
            else:
                print("Gecersiz veya zaten kullandigin silah.")
            bekle()
        elif secim == "4":
            for ad, bilgi in KOSTUMLER.items():
                print(ad, "-", bilgi["maliyet"], "Altin")
            ad = input("Almak istedigin kostum: ").strip()
            if ad in KOSTUMLER:
                if ad == oyuncu["kostum"]:
                    print("Bu kostum zaten kullanimda!")
                    bekle()
                    continue
                maliyet = KOSTUMLER[ad]["maliyet"]
                if oyuncu["altin"] >= maliyet:
                    oyuncu["altin"] -= maliyet
                    oyuncu["kostum"] = ad
                    oyuncu["kostum_seviye"] = 0
                    kayitla_sessiz()
                    print(ad, "giyildi!")
                else:
                    print("Yeterli altinin yok!")
            else:
                print("Gecersiz kostum!")
            bekle()
        elif secim == "5":
            for ad, bilgi in BINEKLER.items():
                print(ad, "-", bilgi["maliyet"], "Altin | Hiz +", bilgi["hiz"])
            ad = input("Almak istedigin binek: ").strip()
            if ad in BINEKLER:
                if ad == oyuncu["binek"]:
                    print("Bu binek zaten kullaniliyor!")
                    bekle()
                    continue
                maliyet = BINEKLER[ad]["maliyet"]
                if oyuncu["altin"] >= maliyet:
                    oyuncu["altin"] -= maliyet
                    oyuncu["binek"] = ad
                    oyuncu["binek_hiz"] = BINEKLER[ad]["hiz"]
                    kayitla_sessiz()
                    print(ad, "alindi!")
                else:
                    print("Yeterli altinin yok!")
            else:
                print("Gecersiz binek!")
            bekle()
        elif secim == "6":
            if oyuncu["altin"] >= 100:
                oyuncu["altin"] -= 100
                oyuncu["hiz_potu"] += 1
                print("Hiz Potu alindi!")
            else:
                print("Yeterli altinin yok!")
            bekle()

# ==========================================
# SAVAŞ
# ==========================================

def savas(dusman_adi, dusman_can, dusman_saldiri, xp, altin):
    while dusman_can > 0 and oyuncu["can"] > 0:
        temizle()
        print("================================")
        print("              SAVAS")
        print("================================")
        print("Dusman:", dusman_adi, "| Can:", dusman_can)
        print("Sen:", oyuncu["isim"], "| Can:", oyuncu["can"], "/", oyuncu["max_can"])
        print("Mana:", oyuncu["mana"], "/", oyuncu["max_mana"])
        print("Saldiri:", silah_saldirisi(), "| Savunma:", toplam_savunma())
        print("\n1 - Normal Saldiri")
        print("2 - Guclu Darbe")
        print("3 - Kritik Vurus")
        print("4 - Can Iksiri")
        print("5 - Kac")
        secim = input("\nSecimin: ")
        hasar = 0

        if secim == "1":
            hasar = max(1, silah_saldirisi() + random.randint(-3, 5))
        elif secim == "2":
            if yetenekler["Guclu Darbe"] <= 0:
                print("Guclu Darbe yetenegin yok!")
                bekle(); continue
            maliyet = 5 if yetenekler["Mana Ustaligi"] > 0 else 10
            if oyuncu["mana"] < maliyet:
                print("Yeterli manan yok!")
                bekle(); continue
            oyuncu["mana"] -= maliyet
            hasar = silah_saldirisi() * 2 + yetenekler["Guclu Darbe"] * 10
        elif secim == "3":
            if yetenekler["Kritik Vurus"] <= 0:
                print("Kritik Vurus yetenegin yok!")
                bekle(); continue
            maliyet = 8 if yetenekler["Mana Ustaligi"] > 0 else 15
            if oyuncu["mana"] < maliyet:
                print("Yeterli manan yok!")
                bekle(); continue
            oyuncu["mana"] -= maliyet
            sans = 20 + yetenekler["Kritik Vurus"] * 10
            hasar = silah_saldirisi() * (3 if random.randint(1, 100) <= sans else 2)
        elif secim == "4":
            if esya_kullan("Can Iksiri"):
                eski = oyuncu["can"]
                oyuncu["can"] = min(oyuncu["max_can"], oyuncu["can"] + 80 + yetenekler["Can Yenileme"] * 20)
                print("Can:", eski, "->", oyuncu["can"])
            else:
                print("Can iksirin yok!")
            bekle(); continue
        elif secim == "5":
            kacis_sansi = min(95, 70 + oyuncu.get("binek_hiz", 0) * 5)
            if oyuncu.get("hiz_potu", 0) > 0:
                kacis_sansi = min(98, kacis_sansi + 10)
            if random.randint(1, 100) <= kacis_sansi:
                if oyuncu.get("hiz_potu", 0) > 0:
                    oyuncu["hiz_potu"] -= 1
                    print("Hiz Potu etkisi kullanildi!")
                print("Savastan kacmayi basardin! (Sans:", kacis_sansi, "%)")
                bekle()
                oyuncu["konum"] = "Koy"
                return False
            print("Kacamadın!")
        else:
            print("Gecersiz secim!")
            bekle(); continue

        if hasar > 0:
            dusman_can -= hasar
            print("Verdigin hasar:", hasar)

        if dusman_can <= 0:
            print("\nDusman yenildi!")
            xp_kazan(xp)
            altin_kazan(altin)
            oyuncu["mana"] = min(oyuncu["max_mana"], oyuncu["mana"] + 5)
            basarim_kontrol()
            bekle()
            return True

        # Savunma sistemi hasari gercekten azaltir.
        gelen = random.randint(max(1, dusman_saldiri - 3), dusman_saldiri + 3)
        azaltma = min(gelen - 1, toplam_savunma() // 2)
        dusman_hasari = max(1, gelen - azaltma)
        # Bolum ilerledikce savunma ve ekipman daha anlamli hale gelir.
        if oyuncu["seviye"] >= 4:
            dusman_hasari = max(1, dusman_hasari - (oyuncu["seviye"] - 3) // 2)
        oyuncu["can"] -= dusman_hasari
        print("Dusman saldirdi! Aldigin hasar:", dusman_hasari)

        if oyuncu["can"] <= 0:
            oyuncu["can"] = max(1, oyuncu["max_can"] // 2)
            oyuncu["konum"] = "Koy"
            print("\nYENILDIN. Koydaki guvenli alana donuyorsun...")
            bekle()
            return False
        bekle()
    return False

# ==========================================
# GOREV / BOLGE GECISLERI
# ==========================================

def bolum_acik_mi(gorev):
    gerekli = BOLUM_SEVIYELERI.get(gorev, 1)
    if oyuncu["seviye"] < gerekli:
        print("Bu bolum icin en az Seviye", gerekli, "gerekiyor.")
        return False
    return True


def gorev_carpani():
    seviye = oyuncu["seviye"]
    if seviye >= 8:
        return 1.25
    if seviye >= 6:
        return 1.15
    if seviye >= 4:
        return 1.10
    return 1.0


def gorev_odulu(sonraki, xp, altin):
    oyuncu["gorev"] = sonraki
    carpan = gorev_carpani()
    xp_odul = math.floor(xp * carpan)
    altin_odul = math.floor(altin * carpan)
    xp_kazan(xp_odul)
    altin_kazan(altin_odul)
    if carpan > 1.0:
        print("Seviye odul bonusu: x" + str(carpan))
    basarim_kontrol()
    veri = {
        "oyuncu": oyuncu.copy(),
        "envanter": envanter.copy(),
        "yetenekler": yetenekler.copy(),
        "basarimlar": basarimlar.copy(),
        "surum": 6,
    }
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as dosya:
            json.dump(veri, dosya, ensure_ascii=False, indent=4)
    except OSError:
        pass


def orman():
    oyuncu["konum"] = "Orman"
    if oyuncu["gorev"] != "Kristali Bul":
        print("Orman gorevi aktif degil.")
        bekle(); return
    dusman = DUSMANLAR["Orman"]
    if savas(*dusman):
        print("GOREV TAMAMLANDI: Kristali Bul")
        gorev_odulu("Magarayi Kesfet", 100, 50)
        esya_ekle("Kristal Parcasi")
        bekle()


def magara():
    oyuncu["konum"] = "Magara"
    if oyuncu["gorev"] != "Magarayi Kesfet":
        print("Magara gorevi su an aktif degil.")
        bekle(); return
    if not bolum_acik_mi("Magarayi Kesfet"):
        bekle(); return
    dusman = DUSMANLAR["Magara"]
    if savas(*dusman):
        print("GOREV TAMAMLANDI: Magarayi Kesfet")
        gorev_odulu("Dag Muhafizini Yen", 150, 100)
        if oyuncu["seviye"] >= 3 and oyuncu["silah"] == "Baslangic Kilici":
            oyuncu["silah"] = "Golge Kilici"
            print("Odul: Golge Kilici acildi!")
        esya_ekle("Golem Parcasi")
        bekle()


def dag():
    oyuncu["konum"] = "Dag"
    if oyuncu["gorev"] != "Dag Muhafizini Yen":
        print("Dag gorevi su an aktif degil.")
        bekle(); return
    if not bolum_acik_mi("Dag Muhafizini Yen"):
        bekle(); return
    dusman = DUSMANLAR["Dag"]
    if savas(*dusman):
        print("GOREV TAMAMLANDI: Dag Muhafizini Yen")
        esya_ekle("Dag Anahtari")
        gorev_odulu("Col Hazinesi", 250, 250)
        if oyuncu["kostum"] == "Gezgin Kostumu":
            oyuncu["kostum"] = "Muhafiz Kostumu"
            print("Odul: Muhafiz Kostumu acildi!")
        bekle()


def col():
    oyuncu["konum"] = "Col"
    if oyuncu["gorev"] != "Col Hazinesi":
        print("Col gorevi su an aktif degil.")
        bekle(); return
    if not bolum_acik_mi("Col Hazinesi"):
        bekle(); return
    dusman = DUSMANLAR["Col"]
    if savas(*dusman):
        print("GOREV TAMAMLANDI: Col Hazinesi")
        esya_ekle("Gizemli Kristal")
        gorev_odulu("Gizemli Portala Gir", 350, 350)
        if oyuncu["binek"] == "Yok":
            oyuncu["binek"] = "At"
            oyuncu["binek_hiz"] = BINEKLER["At"]["hiz"]
            print("Odul: At binek sistemi acildi!")
        bekle()


def final_ekrani():
    global oyun_bitti
    oyun_bitti = True
    temizle()
    print("================================")
    print("       GIZEMLI MACERA")
    print("          TAMAMLANDI")
    print("================================")
    print("Karanlik Lordu yenildi.")
    print("Tum ana gorevler tamamlandi!")
    print("\nOyuncu:", oyuncu["isim"])
    print("Seviye:", oyuncu["seviye"], "| Altin:", oyuncu["altin"])
    print("\nTEBRIKLER! GIZEMLI MACERA'YI TAMAMLADIN!")
    bekle()


def portal():
    oyuncu["konum"] = "Portal"
    if oyuncu["gorev"] == "Oyun Tamamlandi":
        final_ekrani()
        return
    if oyuncu["gorev"] != "Gizemli Portala Gir":
        print("Portal gorevi su an aktif degil.")
        bekle(); return
    if not bolum_acik_mi("Gizemli Portala Gir"):
        bekle(); return
    temizle()
    print("================================")
    print("         GIZEMLI PORTAL")
    print("================================")
    print("1 - Portala gir")
    print("2 - Koy'a don")
    secim = input("\nSecimin: ")
    if secim != "1":
        oyuncu["konum"] = "Koy"
        return
    dusman = DUSMANLAR["Portal"]
    if savas(*dusman):
        gorev_odulu("Oyun Tamamlandi", 1000, 1000)
        basarim_kontrol()
        kayitla_sessiz()
        final_ekrani()

# ==========================================
# MARKET / KOY
# ==========================================

def market():
    while True:
        temizle()
        print("================================")
        print("             MARKET")
        print("================================")
        print("Altin:", oyuncu["altin"])
        print("1 - Can Iksiri 50 Altin")
        print("2 - 3 Can Iksiri 120 Altin")
        print("3 - 100 XP 150 Altin")
        print("4 - Geri Don")
        secim = input("\nSecimin: ")
        if secim == "4": return
        if secim == "1" and oyuncu["altin"] >= 50:
            oyuncu["altin"] -= 50; esya_ekle("Can Iksiri"); print("Can Iksiri alindi!")
        elif secim == "2" and oyuncu["altin"] >= 120:
            oyuncu["altin"] -= 120; esya_ekle("Can Iksiri", 3); print("3 Can Iksiri alindi!")
        elif secim == "3" and oyuncu["altin"] >= 150:
            oyuncu["altin"] -= 150; xp_kazan(100); print("100 XP satin alindi!")
        else:
            print("Yeterli altin yok veya gecersiz secim!")
        bekle()


def koy():
    oyuncu["konum"] = "Koy"
    while True:
        temizle()
        print("================================")
        print("              KOY")
        print("================================")
        print("Can:", oyuncu["can"], "/", oyuncu["max_can"], "Mana:", oyuncu["mana"], "/", oyuncu["max_mana"])
        print("1 - Dinlen")
        print("2 - Haritaya Don")
        secim = input("\nSecimin: ")
        if secim == "1":
            oyuncu["can"] = oyuncu["max_can"]
            oyuncu["mana"] = oyuncu["max_mana"]
            print("Can ve mana tamamen yenilendi!")
            bekle()
        elif secim == "2": return

# ==========================================
# YENI OYUN / HARITA
# ==========================================

def yeni_oyun():
    global oyun_bitti
    isim = input("Oyuncu adin: ").strip() or "Oyuncu"
    # Tum yeni oyun alanlarini sifirla.
    varsayilan = {
        "isim": isim, "can": 100, "max_can": 100, "mana": 50, "max_mana": 50,
        "altin": 1000, "seviye": 1, "xp": 0, "saldiri": 10, "savunma": 0,
        "konum": "Koy", "gorev": "Kristali Bul", "skill_puani": 0,
        "silah": "Baslangic Kilici", "silah_plus": 0, "kostum": "Gezgin Kostumu",
        "kostum_seviye": 0, "binek": "Yok", "binek_hiz": 0, "hiz_potu": 0,
    }
    oyuncu.update(varsayilan)
    oyun_bitti = False
    envanter.clear(); envanter.update({"Can Iksiri": 3})
    for k in yetenekler: yetenekler[k] = 0
    for k in basarimlar: basarimlar[k] = False
    harita()


def harita():
    while True:
        if oyun_bitti:
            return
        temizle()
        print("================================")
        print("             HARITA")
        print("================================")
        print("Oyuncu:", oyuncu["isim"])
        print("Can:", oyuncu["can"], "/", oyuncu["max_can"], "| Mana:", oyuncu["mana"], "/", oyuncu["max_mana"])
        print("Altin:", oyuncu["altin"], "| Seviye:", oyuncu["seviye"])
        print("Saldiri:", silah_saldirisi(), "| Savunma:", toplam_savunma())
        print("Konum:", oyuncu["konum"])
        print("Gorev:", oyuncu["gorev"])
        print("\n1 - Koy\n2 - Orman\n3 - Magara\n4 - Dag\n5 - Col\n6 - Portal")
        print("7 - Market\n8 - Karakter\n9 - Envanter\n10 - Kaydet\n11 - Ana Menu\n12 - Basarimlar\n13 - Yetenekler\n14 - Gelistirmeler\n15 - Bolum Durumu")
        secim = input("\nSecimin: ")
        if secim == "1": koy()
        elif secim == "2": orman()
        elif secim == "3": magara()
        elif secim == "4": dag()
        elif secim == "5": col()
        elif secim == "6": portal()
        elif secim == "7": market()
        elif secim == "8": karakter()
        elif secim == "9": envanter_goster()
        elif secim == "10": kaydet()
        elif secim == "11": return
        elif secim == "12": basarimlari_goster()
        elif secim == "13": yetenekler_menu()
        elif secim == "14": gelistirmeler()
        elif secim == "15": bolum_bilgisi()
        else:
            print("Gecersiz secim!")
            bekle()


def ana_menu():
    muzik_hazirla_ve_baslat()
    while True:
        temizle()
        print("================================")
        print("        GIZEMLI MACERA")
        print("================================")
        print("1 - Yeni Oyun")
        print("2 - Kayit Yukle")
        print("3 - Oyundan Cik")
        secim = input("\nSecimin: ")
        if secim == "1":
            yeni_oyun()
            if oyun_bitti:
                break
        elif secim == "2":
            if kayit_yukle():
                harita()
                if oyun_bitti:
                    break
        elif secim == "3":
            muzik_durdur()
            print("Gorusuruz!")
            break
        else:
            print("Gecersiz secim!")
            bekle()


if __name__ == "__main__":
    ana_menu()
