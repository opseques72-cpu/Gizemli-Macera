GIZEMLI MACERA - ANDROID HAZIRLIK

Bu klasor Android APK derlemesi icin hazirlanmistir.
Ana oyun mantigi gizemli_macera.py dosyasindan gelir.
main.py, mevcut metin tabanli oyunu dokunmatik butonlarla calistiran mobil arayuzdur.

APK derleme icin Linux/WSL ortaminda Buildozer gerekir:
buildozer -v android debug

Olusan APK normalde bin/ klasorunde bulunur.
