import builtins
import os
import queue
import threading

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput

import gizemli_macera as game

INPUTS = queue.Queue()
ORIGINAL_INPUT = builtins.input
ORIGINAL_PRINT = builtins.print


def mobile_input(prompt=""):
    if prompt:
        ORIGINAL_PRINT(prompt, end="")
    return INPUTS.get()


def mobile_print(*args, **kwargs):
    text = " ".join(str(a) for a in args)
    if kwargs.get("end", "\n") != "":
        text += kwargs.get("end", "\n")
    Clock.schedule_once(lambda dt: App.get_running_app().append_output(text), 0)


builtins.input = mobile_input
builtins.print = mobile_print


class GameApp(App):
    def build(self):
        self.title = "Gizemli Macera"
        game.SAVE_FILE = os.path.join(self.user_data_dir, "kayit.json")

        root = BoxLayout(orientation="vertical", padding=8, spacing=6)
        self.output = Label(text="GIZEMLI MACERA\n", size_hint_y=None, halign="left", valign="top")
        self.output.bind(texture_size=lambda obj, size: setattr(obj, "height", size[1]))
        scroll = ScrollView()
        scroll.add_widget(self.output)
        root.add_widget(scroll)

        self.name = TextInput(hint_text="Oyuncu adı (Yeni Oyun'da)", multiline=False, size_hint_y=None, height=45)
        root.add_widget(self.name)

        grid = GridLayout(cols=5, spacing=4, size_hint_y=None, height=210)
        for n in range(1, 16):
            b = Button(text=str(n), font_size=18)
            b.bind(on_release=lambda btn, value=str(n): self.send(value))
            grid.add_widget(b)
        root.add_widget(grid)

        bottom = BoxLayout(size_hint_y=None, height=48, spacing=5)
        self.entry = TextInput(hint_text="Seçim yaz", multiline=False)
        send = Button(text="GÖNDER", size_hint_x=None, width=110)
        send.bind(on_release=lambda *_: self.send(self.entry.text))
        bottom.add_widget(self.entry)
        bottom.add_widget(send)
        root.add_widget(bottom)

        threading.Thread(target=self.run_game, daemon=True).start()
        return root

    def append_output(self, text):
        self.output.text += text
        self.output.texture_update()

    def send(self, value):
        value = str(value).strip()
        if not value:
            return
        if value == "1" and self.name.text.strip():
            # The first input after Yeni Oyun is the player name.
            pass
        INPUTS.put(value)
        self.entry.text = ""

    def run_game(self):
        try:
            game.ana_menu()
        except Exception as exc:
            mobile_print("\nHATA:", exc)


if __name__ == "__main__":
    GameApp().run()
